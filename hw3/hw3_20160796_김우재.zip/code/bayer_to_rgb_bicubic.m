%% HW3-a
% Generate the rgb image from the bayer pattern image using linear and
% bicubic interpolation.
function rgb_img = bayer_to_rgb_bicubic(bayer_img)

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Your code here
    % Initialize images
    [M, N] = size(bayer_img);
    img = uint8(zeros(M, N, 3));
    red_bayer = double(zeros(M, N));
    green_bayer = double(zeros(M, N));
    blue_bayer = double(zeros(M, N));
    
    % Fill in each Bayer channel
    for i = 1:M
        for j = 1:N
            if (rem(i,2) == 1) && (rem(j,2) == 1) 
                red_bayer(i,j) = bayer_img(i,j);
            elseif (rem(i,2) == 0) && (rem(j,2) == 0)
                blue_bayer(i,j) = bayer_img(i,j);
            else
                green_bayer(i,j) = bayer_img(i,j);
            end
        end
    end
                
    % Interpolate each image channel
    for i = 1:M
        for j = 1:N
            if (rem(i,2) == 1 && rem(j,2) == 1) %Red Bayer
                if (i == 1 && j == 1) %Top left corner
                    green_bayer(i,j) = (green_bayer(i+1,j) + green_bayer(i,j+1)) / 2;
                    blue_bayer(i,j) = blue_bayer(i+1,j+1);
                elseif (i == 1 && j ~= 1) %Top row
                    green_bayer(i,j) = (green_bayer(i,j-1) + green_bayer(i,j+1) + green_bayer(i+1,j)) / 3;
                    blue_bayer(i,j) = (blue_bayer(i+1,j-1) + blue_bayer(i+1,j+1)) / 2;
                elseif (i ~= 1 && j == 1) %Left column
                    green_bayer(i,j) = (green_bayer(i+1,j) + green_bayer(i-1,j) + green_bayer(i,j+1)) / 3;
                    blue_bayer(i,j) = (blue_bayer(i+1,j+1) + blue_bayer(i-1,j+1)) / 2;
                else
                    green_bayer(i,j) = (green_bayer(i-1,j) + green_bayer(i+1,j) + green_bayer(i,j-1) + green_bayer(i,j+1)) / 4;
                    blue_bayer(i,j) = (blue_bayer(i-1,j-1) + blue_bayer(i-1,j+1) + blue_bayer(i+1,j-1) + blue_bayer(i+1,j+1)) / 4;
                end
            elseif (rem(i,2) == 0 && rem(j,2) == 0) %Blue Bayer
                if (i == M && j == N) %Bottom right corner
                    red_bayer(i,j) = red_bayer(i-1,j-1);
                    green_bayer(i,j) = (green_bayer(i-1,j) + green_bayer(i,j-1)) / 2;
                elseif (i == M && j ~= N) %Bottom row
                    red_bayer(i,j) = (red_bayer(i-1,j-1) + red_bayer(i-1,j+1)) / 2;
                    green_bayer(i,j) = (green_bayer(i,j-1) + green_bayer(i,j+1) + green_bayer(i-1,j)) / 3;
                elseif (i ~= M && j == N) %Right column
                    red_bayer(i,j) = (red_bayer(i-1,j-1) + red_bayer(i+1,j-1)) / 2;
                    green_bayer(i,j) = (green_bayer(i-1,j) + green_bayer(i+1,j) + green_bayer(i,j-1)) / 3;
                else
                    red_bayer(i,j) = (red_bayer(i-1,j-1) + red_bayer(i-1,j+1) + red_bayer(i+1,j-1) + red_bayer(i+1,j+1)) / 4;
                    green_bayer(i,j) = (green_bayer(i-1,j) + green_bayer(i+1,j) + green_bayer(i,j-1) + green_bayer(i,j+1)) / 4;
                end
            elseif (rem(i,2) == 0 && rem(j,2) == 1) %Green Bayer
                if (i == M && j == 1) %Bottom left corner
                    red_bayer(i,j) = red_bayer(i-1,j);
                    blue_bayer(i,j) = blue_bayer(i, j+1);
                elseif (i ~= M && j == 1) %Left column
                    red_bayer(i,j) = (red_bayer(i-1,j) + red_bayer(i+1,j)) / 2;
                    blue_bayer(i,j) = blue_bayer(i,j+1);
                elseif (i == M && j ~= 1) %Bottom row
                    red_bayer(i,j) = red_bayer(i-1,j);
                    blue_bayer(i,j) = (blue_bayer(i,j-1) + blue_bayer(i,j+1)) / 2;
                else
                    red_bayer(i,j) = (red_bayer(i-1,j) + red_bayer(i+1,j)) / 2;
                    blue_bayer(i,j) = (blue_bayer(i,j-1) + blue_bayer(i,j+1)) / 2;
                end 
            elseif (rem(i,2) == 1 && rem(j,2) == 0) %Green bayer
                if (i == 1 && j == N) %Top right corner
                    red_bayer(i,j) = red_bayer(i,j-1);
                    blue_bayer(i,j) = blue_bayer(i+1,j);
                elseif (i ~= 1 && j == N) %Right column
                    red_bayer(i,j) = red_bayer(i,j-1);
                    blue_bayer(i,j) = (blue_bayer(i-1,j) + blue_bayer(i+1,j)) / 2;
                elseif (i == 1 && j ~= N) %Top row
                    red_bayer(i,j) = (red_bayer(i,j-1) + red_bayer(i,j+1)) / 2;
                    blue_bayer(i,j) = blue_bayer(i+1,j);
                else
                    red_bayer(i,j) = (red_bayer(i,j-1) + red_bayer(i,j+1)) / 2;
                    blue_bayer(i,j) = (blue_bayer(i-1,j) + blue_bayer(i+1,j)) / 2;
                end
            end                
        end
    end

    img(:,:,1) = uint8(red_bayer);
    img(:,:,2) = uint8(green_bayer);
    img(:,:,3) = uint8(blue_bayer);
    rgb_img = img;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
end
